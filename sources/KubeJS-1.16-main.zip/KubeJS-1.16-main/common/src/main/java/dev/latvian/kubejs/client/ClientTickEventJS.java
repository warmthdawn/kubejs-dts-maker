package dev.latvian.kubejs.client;

/**
 * @author LatvianModder
 */
public class ClientTickEventJS extends ClientEventJS {
}