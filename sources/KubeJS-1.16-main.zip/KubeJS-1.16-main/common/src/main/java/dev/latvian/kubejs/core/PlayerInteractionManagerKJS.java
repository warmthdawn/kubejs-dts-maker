package dev.latvian.kubejs.core;

/**
 * @author LatvianModder
 */
public interface PlayerInteractionManagerKJS {
	boolean isDestroyingBlockKJS();
}