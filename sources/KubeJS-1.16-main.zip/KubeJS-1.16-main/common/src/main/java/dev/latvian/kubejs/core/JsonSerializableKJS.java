package dev.latvian.kubejs.core;

import com.google.gson.JsonElement;

public interface JsonSerializableKJS {
	JsonElement toJsonKJS();
}
