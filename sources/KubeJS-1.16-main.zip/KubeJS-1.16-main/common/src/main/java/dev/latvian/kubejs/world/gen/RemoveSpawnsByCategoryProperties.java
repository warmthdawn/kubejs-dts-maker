package dev.latvian.kubejs.world.gen;

/**
 * @author LatvianModder
 */
public class RemoveSpawnsByCategoryProperties {
	public final WorldgenEntryList biomes = new WorldgenEntryList();
	public final WorldgenEntryList categories = new WorldgenEntryList();
}
