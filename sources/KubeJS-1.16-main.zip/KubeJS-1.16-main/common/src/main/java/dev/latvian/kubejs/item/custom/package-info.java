@dev.latvian.kubejs.NonnullByDefault
package dev.latvian.kubejs.item.custom;