package dev.latvian.kubejs.net;

import dev.latvian.kubejs.client.ClientEventJS;

public class PainterUpdatedEventJS extends ClientEventJS {
}
