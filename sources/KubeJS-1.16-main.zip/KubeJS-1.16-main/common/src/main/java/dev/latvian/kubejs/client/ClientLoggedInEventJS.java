package dev.latvian.kubejs.client;

/**
 * @author LatvianModder
 */
public class ClientLoggedInEventJS extends ClientEventJS {
}