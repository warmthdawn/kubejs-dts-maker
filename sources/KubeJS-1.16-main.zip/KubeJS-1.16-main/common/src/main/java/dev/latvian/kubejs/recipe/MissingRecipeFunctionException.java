package dev.latvian.kubejs.recipe;

/**
 * @author LatvianModder
 */
public class MissingRecipeFunctionException extends RecipeExceptionJS {
	public MissingRecipeFunctionException(String message) {
		super(message);
	}
}