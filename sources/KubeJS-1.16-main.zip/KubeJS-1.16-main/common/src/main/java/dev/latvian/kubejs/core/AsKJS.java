package dev.latvian.kubejs.core;

public interface AsKJS {
	Object asKJS();
}
