package dev.latvian.kubejs.core;

import net.minecraft.world.level.material.Fluid;

/**
 * @author LatvianModder
 */
public interface BucketItemKJS {
	Fluid getFluidKJS();
}
