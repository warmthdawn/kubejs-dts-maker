package dev.latvian.kubejs.core;

import net.minecraft.tags.Tag;

import java.util.List;

/**
 * @author LatvianModder
 */
public interface TagBuilderKJS {
	List<Tag.BuilderEntry> getProxyListKJS();
}
