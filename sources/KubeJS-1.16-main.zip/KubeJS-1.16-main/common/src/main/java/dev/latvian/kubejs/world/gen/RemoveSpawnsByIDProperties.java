package dev.latvian.kubejs.world.gen;

/**
 * @author LatvianModder
 */
public class RemoveSpawnsByIDProperties {
	public final WorldgenEntryList biomes = new WorldgenEntryList();
	public final WorldgenEntryList entities = new WorldgenEntryList();
}
