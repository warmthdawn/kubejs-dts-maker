package dev.latvian.kubejs.core;

import net.minecraft.resources.ResourceLocation;

/**
 * @author LatvianModder
 */
public interface ImageButtonKJS {
	ResourceLocation getButtonTextureKJS();
}