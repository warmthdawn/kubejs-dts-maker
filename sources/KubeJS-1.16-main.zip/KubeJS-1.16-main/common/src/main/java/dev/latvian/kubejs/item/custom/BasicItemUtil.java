package dev.latvian.kubejs.item.custom;

import dev.latvian.kubejs.item.ItemBuilder;
import dev.architectury.injectables.annotations.ExpectPlatform;

public class BasicItemUtil {
	@ExpectPlatform
	public static BasicItemJS createBasicItem(ItemBuilder p) {
		throw new AssertionError();
	}
}
