package dev.latvian.kubejs.entity;

/**
 * @author LatvianModder
 */
public abstract class LivingEntityEventJS extends EntityEventJS {
}