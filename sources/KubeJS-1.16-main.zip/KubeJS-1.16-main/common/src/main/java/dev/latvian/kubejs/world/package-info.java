@dev.latvian.kubejs.NonnullByDefault
package dev.latvian.kubejs.world;