package dev.latvian.kubejs.core;

/**
 * @author LatvianModder
 */
public interface FireworkRocketEntityKJS {
	void setLifetimeKJS(int lifetime);
}