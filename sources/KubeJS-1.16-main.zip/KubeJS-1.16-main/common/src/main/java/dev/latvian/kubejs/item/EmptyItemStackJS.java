package dev.latvian.kubejs.item;

/**
 * @author LatvianModder
 */
@Deprecated
public class EmptyItemStackJS {
	@Deprecated
	public static final ItemStackJS INSTANCE = ItemStackJS.EMPTY;
}