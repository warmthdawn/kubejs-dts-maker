@dev.latvian.kubejs.NonnullByDefault
package dev.latvian.kubejs.client.painter.world;