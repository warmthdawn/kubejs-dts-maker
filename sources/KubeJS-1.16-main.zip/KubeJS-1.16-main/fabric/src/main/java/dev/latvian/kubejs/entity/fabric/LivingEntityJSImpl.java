package dev.latvian.kubejs.entity.fabric;

import net.minecraft.world.entity.LivingEntity;

public class LivingEntityJSImpl {
	public static double getReachDistance(LivingEntity livingEntity) {
		return 5;
	}
}
