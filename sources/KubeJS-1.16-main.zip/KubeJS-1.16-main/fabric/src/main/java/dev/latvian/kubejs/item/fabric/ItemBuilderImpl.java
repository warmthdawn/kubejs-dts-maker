package dev.latvian.kubejs.item.fabric;

import me.shedaniel.architectury.registry.ToolType;
import net.minecraft.world.item.Item;

public class ItemBuilderImpl {
	public static void appendToolType(Item.Properties properties, ToolType type, Integer level) {
		// NO-OP
	}
}
