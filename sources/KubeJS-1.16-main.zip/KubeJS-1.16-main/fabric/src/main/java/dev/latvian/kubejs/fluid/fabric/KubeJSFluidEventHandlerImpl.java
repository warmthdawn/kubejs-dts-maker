package dev.latvian.kubejs.fluid.fabric;

import dev.latvian.kubejs.fluid.FluidBuilder;
import net.minecraft.world.level.material.FlowingFluid;

public class KubeJSFluidEventHandlerImpl {
	public static FlowingFluid buildFluid(boolean source, FluidBuilder builder) {
		return null;
	}
}
