package dev.latvian.kubejs;

@FunctionalInterface
public interface KubeJSInitializer {
	void onKubeJSInitialization();
}