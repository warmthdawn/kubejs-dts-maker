package dev.latvian.mods.rhino.mod.fabric;

import net.fabricmc.api.ModInitializer;

public class RhinoModFabric implements ModInitializer {
	@Override
	public void onInitialize() {
	}
}
