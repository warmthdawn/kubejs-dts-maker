package dev.latvian.mods.rhino.mod.util;

/**
 * @author LatvianModder
 */
public interface StringBuilderAppendable {
	void appendString(StringBuilder builder);
}
