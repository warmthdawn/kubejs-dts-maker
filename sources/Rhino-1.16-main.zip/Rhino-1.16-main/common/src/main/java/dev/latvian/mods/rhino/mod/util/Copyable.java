package dev.latvian.mods.rhino.mod.util;

/**
 * @author LatvianModder
 */
public interface Copyable {
	Copyable copy();
}