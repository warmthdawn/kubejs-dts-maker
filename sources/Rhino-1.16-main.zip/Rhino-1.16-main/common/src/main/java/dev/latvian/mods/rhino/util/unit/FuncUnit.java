package dev.latvian.mods.rhino.util.unit;

public abstract class FuncUnit extends Unit {
	public abstract String getFuncName();
}