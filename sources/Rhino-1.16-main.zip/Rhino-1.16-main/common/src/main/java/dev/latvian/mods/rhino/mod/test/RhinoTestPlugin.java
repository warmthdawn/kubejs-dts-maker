package dev.latvian.mods.rhino.mod.test;

public class RhinoTestPlugin {
	/*
	@Override
	public void addBindings(BindingsEvent event) {
		if (Platform.isDevelopmentEnvironment()) {
			event.add("TestConsole", new TestConsole());
			event.add("RhinoRect", RhinoRect.class);

			event.add("RhinoTest", new RhinoTest());
			event.addFunction("sqTest", o -> ((Number) o[0]).doubleValue() * ((Number) o[0]).doubleValue());

			event.add("NBTTest", NBTWrapper.class);
		}
	}
	 */
}
