package dev.latvian.mods.rhino.mod.util;

import com.google.gson.JsonElement;

/**
 * @author LatvianModder
 */
public interface JsonSerializable {
	JsonElement toJson();
}