package dev.latvian.mods.rhino.mod.forge;

import net.minecraftforge.fml.common.Mod;

@Mod("rhino")
public class RhinoModForge {
}
